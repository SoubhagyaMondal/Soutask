export 'bindings/splash_binding.dart';
export 'controllers/splash_controller.dart';
export 'views/splash_view.dart';